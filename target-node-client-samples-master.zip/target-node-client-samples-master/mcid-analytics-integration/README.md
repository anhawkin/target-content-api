# MCID and Analytics integration sample

## Usage
1. `npm install`
2. `npm run www`
