# MCID and Analytics and at.js integration sample

## Usage
1. `npm install`
2. `npm run www`
